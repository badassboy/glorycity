package com.example.glorycity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
